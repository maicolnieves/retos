package com.example.reto1;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    /**
     *
     *
     * @autor maicol
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    /**
     *
     *
     * @author maicol
     */
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menuopciones, menu);
        return true;
    }

    /**
     *
     *
     * @author maicol
     */
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int id = item.getItemId();

        if (id == R.id.opcion1){
            Toast.makeText(getApplicationContext(), "Productos", Toast.LENGTH_LONG).show();
            Intent segundapantalla = new Intent(this, MainActivity2.class);
            startActivity(segundapantalla);
        }
        if (id == R.id.opcion2){
            Toast.makeText(getApplicationContext(), "Servicios", Toast.LENGTH_LONG).show();
            Intent tercerapantalla = new Intent(this, MainActivity3.class);
            startActivity(tercerapantalla);
        }
        if (id == R.id.opcion3){
            Toast.makeText(getApplicationContext(), "Sucursales", Toast.LENGTH_LONG).show();
            Intent cuartapantalla = new Intent(this, MainActivity4.class);
            startActivity(cuartapantalla);
        }
        return super.onOptionsItemSelected(item);
    }
}