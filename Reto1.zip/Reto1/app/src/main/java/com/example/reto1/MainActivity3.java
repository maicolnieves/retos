package com.example.reto1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.widget.ImageView;

public class MainActivity3 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);

        Resources res = getResources();
        Drawable drawable = res.getDrawable(R.drawable.domici, getTheme());

        ImageView imagen2 = (ImageView) findViewById(R.id.imagen2);
        imagen2.setImageDrawable(drawable);
    }
}