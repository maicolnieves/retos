package com.example.reto1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.widget.ImageView;

public class MainActivity2 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        Resources res = getResources();
        Drawable drawable = res.getDrawable(R.drawable.produ, getTheme());

        ImageView imagen1 = (ImageView) findViewById(R.id.imagen1);
        imagen1.setImageDrawable(drawable);
    }
}