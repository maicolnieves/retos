package com.example.reto1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.widget.ImageView;

public class MainActivity4 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main4);

        Resources res = getResources();
        Drawable drawable = res.getDrawable(R.drawable.ma, getTheme());

        ImageView imagen3 = (ImageView) findViewById(R.id.imagen3);
        imagen3.setImageDrawable(drawable);
    }
}